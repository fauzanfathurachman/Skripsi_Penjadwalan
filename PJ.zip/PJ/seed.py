from app import app
from models import db, Subject, Teacher, Classroom, TimeSlot, Schedule, User

def seed_database():
    with app.app_context():
        print("Mengahapus data jadwal lama...")
        db.session.query(Schedule).delete()
        
        print("Menghapus data master lama...")
        db.session.query(Teacher).delete()
        db.session.query(Subject).delete()
        db.session.query(Classroom).delete()
        db.session.query(TimeSlot).delete()

        db.session.commit()

        # 1. Seed Mata Pelajaran (Kurikulum Merdeka SMP)
        print("Menyemai data Mata Pelajaran...")
        subjects_data = [
            {"name": "Pendidikan Agama", "alloc": 3},
            {"name": "Pendidikan Pancasila", "alloc": 3},
            {"name": "Bahasa Indonesia", "alloc": 6},
            {"name": "Matematika", "alloc": 5},
            {"name": "Ilmu Pengetahuan Alam (IPA)", "alloc": 5},
            {"name": "Ilmu Pengetahuan Sosial (IPS)", "alloc": 4},
            {"name": "Bahasa Inggris", "alloc": 4},
            {"name": "PJOK (Olahraga)", "alloc": 3},
            {"name": "Seni Budaya", "alloc": 3},
            {"name": "Informatika", "alloc": 2},
            {"name": "Muatan Lokal (Bahasa Daerah)", "alloc": 2},
        ]
        
        subject_objects = {}
        for data in subjects_data:
            subj = Subject(name=data["name"], weekly_allocations=data["alloc"])
            db.session.add(subj)
            db.session.flush() # flush to get ID
            subject_objects[data["name"]] = subj

        # 2. Seed Data Guru (19 Guru A-S)
        print("Menyemai data Guru...")
        teachers_mapping = {
            "Pendidikan Agama": ["Ahmad Hidayat, S.Ag."],
            "Pendidikan Pancasila": ["Drs. Budi Santoso, M.Pd."],
            "Bahasa Indonesia": ["Siti Aminah, S.Pd.", "Rina Kusumawati, S.Pd."],
            "Matematika": ["Eko Prasetyo, S.Pd.", "Sri Rahayu, S.Pd."],
            "Ilmu Pengetahuan Alam (IPA)": ["Hendra Gunawan, M.Si.", "Fitriani, S.Pd., M.Sc."],
            "Ilmu Pengetahuan Sosial (IPS)": ["Dra. Ratna Sari, M.Pd.", "Agus Setiawan, S.Pd."],
            "Bahasa Inggris": ["Diana Putri, S.Pd.", "Kevin Pratama, S.Pd., M.Ed."],
            "PJOK (Olahraga)": ["Dedi Mulyadi, S.Or.", "Bambang Saputra, S.Pd."],
            "Seni Budaya": ["Wawan Sudarman, S.Sn.", "Nia Lestari, S.Pd."],
            "Informatika": ["Reza Kurniawan, S.Kom.", "Arief Hidayat, S.T."],
            "Muatan Lokal (Bahasa Daerah)": ["Asep Sunandar, S.Pd."],
        }
        
        for subj_name, teacher_names in teachers_mapping.items():
            subj_id = subject_objects[subj_name].id
            for t_name in teacher_names:
                teacher = Teacher(name=t_name, subject_id=subj_id)
                db.session.add(teacher)

        # 3. Seed Data Kelas (6 Kelas)
        print("Menyemai data Kelas...")
        classrooms = ["VII-A", "VII-B", "VIII-A", "VIII-B", "IX-A", "IX-B"]
        for c_name in classrooms:
            classroom = Classroom(name=c_name)
            db.session.add(classroom)

        # 4. Seed Data Waktu/Sesi (Senin - Jumat)
        print("Menyemai data Waktu/Sesi...")
        days = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat"]
        
        # Timeline per hari: 8 JP + 2 Istirahat
        # JP 1: 07:00 - 07:40
        # JP 2: 07:40 - 08:20
        # JP 3: 08:20 - 09:00
        # Istirahat 1: 09:00 - 09:30
        # JP 4: 09:30 - 10:10
        # JP 5: 10:10 - 10:50
        # Istirahat 2: 10:50 - 11:20
        # JP 6: 11:20 - 12:00
        # JP 7: 12:00 - 12:40
        # JP 8: 12:40 - 13:20
        
        timeline = [
            ("07:00", "07:40", False), # JP 1
            ("07:40", "08:20", False), # JP 2
            ("08:20", "09:00", False), # JP 3
            ("09:00", "09:30", True),  # Istirahat 1
            ("09:30", "10:10", False), # JP 4
            ("10:10", "10:50", False), # JP 5
            ("10:50", "11:20", True),  # Istirahat 2
            ("11:20", "12:00", False), # JP 6
            ("12:00", "12:40", False), # JP 7
            ("12:40", "13:20", False), # JP 8
        ]

        for day in days:
            for start_time, end_time, is_break in timeline:
                slot = TimeSlot(
                    day_of_week=day,
                    start_time=start_time,
                    end_time=end_time,
                    is_break=is_break
                )
                db.session.add(slot)

        # Commit all master data
        db.session.commit()
        print("SELESAI! Database telah berhasil disemai dengan data dummy SMP.")

if __name__ == '__main__':
    seed_database()
