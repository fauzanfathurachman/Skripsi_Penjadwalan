from flask import Flask, render_template, request, redirect, url_for, flash
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from models import db, User, Subject, Teacher, Classroom, TimeSlot, Schedule, TeacherUnavailable
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'supersecretkey'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///schedule.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Silakan login terlebih dahulu untuk mengakses halaman ini.'
login_manager.login_message_category = 'warning'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

with app.app_context():
    db.create_all()
    # Seed default admin if not exists
    if not User.query.filter_by(username='admin').first():
        admin_user = User(
            username='admin', 
            password_hash=generate_password_hash('admin'), 
            role='admin'
        )
        db.session.add(admin_user)
        db.session.commit()

# --- AUTH ROUTES ---
@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            flash('Login berhasil! Selamat datang.', 'success')
            next_page = request.args.get('next')
            return redirect(next_page if next_page else url_for('dashboard'))
        else:
            flash('Username atau password salah.', 'danger')
            
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Anda telah logout.', 'info')
    return redirect(url_for('login'))

# --- DASHBOARD (Admin Only) ---
@app.route('/')
def index():
    if current_user.is_authenticated and current_user.role == 'admin':
        return redirect(url_for('dashboard'))
    return redirect(url_for('schedules')) # Tamu goes to schedules

@app.route('/dashboard')
@login_required
def dashboard():
    if current_user.role != 'admin':
        flash('Akses ditolak.', 'danger')
        return redirect(url_for('schedules'))
        
    total_teachers = Teacher.query.count()
    total_classrooms = Classroom.query.count()
    total_subjects = Subject.query.count()
    return render_template('dashboard.html', 
                           total_teachers=total_teachers,
                           total_classrooms=total_classrooms,
                           total_subjects=total_subjects)

# --- TEACHER CRUD (Admin Only) ---
@app.route('/teachers')
@login_required
def teachers():
    if current_user.role != 'admin': return redirect(url_for('schedules'))
    teachers = Teacher.query.all()
    subjects = Subject.query.all()
    return render_template('teachers.html', teachers=teachers, subjects=subjects)

@app.route('/teachers/add', methods=['POST'])
@login_required
def add_teacher():
    if current_user.role != 'admin': return redirect(url_for('schedules'))
    name = request.form.get('name')
    subject_id = request.form.get('subject_id')
    if name and subject_id:
        new_teacher = Teacher(name=name, subject_id=subject_id)
        db.session.add(new_teacher)
        db.session.commit()
        flash('Guru berhasil ditambahkan!', 'success')
    return redirect(url_for('teachers'))

@app.route('/teachers/delete/<int:id>', methods=['POST'])
@login_required
def delete_teacher(id):
    if current_user.role != 'admin': return redirect(url_for('schedules'))
    teacher = Teacher.query.get_or_404(id)
    Schedule.query.filter_by(teacher_id=id).delete()
    db.session.delete(teacher)
    db.session.commit()
    flash('Guru berhasil dihapus!', 'success')
    return redirect(url_for('teachers'))

# --- CLASSROOM CRUD (Admin Only) ---
@app.route('/classrooms')
@login_required
def classrooms():
    if current_user.role != 'admin': return redirect(url_for('schedules'))
    classrooms = Classroom.query.all()
    return render_template('classrooms.html', classrooms=classrooms)

@app.route('/classrooms/add', methods=['POST'])
@login_required
def add_classroom():
    if current_user.role != 'admin': return redirect(url_for('schedules'))
    name = request.form.get('name')
    if name:
        new_class = Classroom(name=name)
        db.session.add(new_class)
        db.session.commit()
        flash('Kelas berhasil ditambahkan!', 'success')
    return redirect(url_for('classrooms'))

@app.route('/classrooms/delete/<int:id>', methods=['POST'])
@login_required
def delete_classroom(id):
    if current_user.role != 'admin': return redirect(url_for('schedules'))
    classroom = Classroom.query.get_or_404(id)
    Schedule.query.filter_by(classroom_id=id).delete()
    db.session.delete(classroom)
    db.session.commit()
    flash('Kelas berhasil dihapus!', 'success')
    return redirect(url_for('classrooms'))

# --- SUBJECT CRUD (Admin Only) ---
@app.route('/subjects')
@login_required
def subjects():
    if current_user.role != 'admin': return redirect(url_for('schedules'))
    subjects = Subject.query.all()
    return render_template('subjects.html', subjects=subjects)

@app.route('/subjects/add', methods=['POST'])
@login_required
def add_subject():
    if current_user.role != 'admin': return redirect(url_for('schedules'))
    name = request.form.get('name')
    weekly_allocations = request.form.get('weekly_allocations', type=int)
    if name and weekly_allocations:
        new_subject = Subject(name=name, weekly_allocations=weekly_allocations)
        db.session.add(new_subject)
        db.session.commit()
        flash('Mata Pelajaran berhasil ditambahkan!', 'success')
    return redirect(url_for('subjects'))

@app.route('/subjects/delete/<int:id>', methods=['POST'])
@login_required
def delete_subject(id):
    if current_user.role != 'admin': return redirect(url_for('schedules'))
    subject = Subject.query.get_or_404(id)
    Schedule.query.filter_by(subject_id=id).delete()
    db.session.delete(subject)
    db.session.commit()
    flash('Mata Pelajaran berhasil dihapus!', 'success')
    return redirect(url_for('subjects'))

# --- TIMESLOT CRUD (Admin Only) ---
@app.route('/timeslots')
@login_required
def timeslots():
    if current_user.role != 'admin': return redirect(url_for('schedules'))
    timeslots = TimeSlot.query.order_by(TimeSlot.day_of_week, TimeSlot.start_time).all()
    return render_template('timeslots.html', timeslots=timeslots)

@app.route('/timeslots/add', methods=['POST'])
@login_required
def add_timeslot():
    if current_user.role != 'admin': return redirect(url_for('schedules'))
    day_of_week = request.form.get('day_of_week')
    start_time = request.form.get('start_time')
    end_time = request.form.get('end_time')
    is_break = request.form.get('is_break') == 'on'
    if day_of_week and start_time and end_time:
        new_slot = TimeSlot(day_of_week=day_of_week, start_time=start_time, end_time=end_time, is_break=is_break)
        db.session.add(new_slot)
        db.session.commit()
        flash('Sesi waktu berhasil ditambahkan!', 'success')
    return redirect(url_for('timeslots'))

@app.route('/timeslots/delete/<int:id>', methods=['POST'])
@login_required
def delete_timeslot(id):
    if current_user.role != 'admin': return redirect(url_for('schedules'))
    slot = TimeSlot.query.get_or_404(id)
    Schedule.query.filter_by(timeslot_id=id).delete()
    db.session.delete(slot)
    db.session.commit()
    flash('Sesi waktu berhasil dihapus!', 'success')
    return redirect(url_for('timeslots'))

# --- TEACHER UNAVAILABLE CRUD (Admin Only) ---
@app.route('/unavailables')
@login_required
def unavailables():
    if current_user.role != 'admin': return redirect(url_for('schedules'))
    unavailables = TeacherUnavailable.query.join(TimeSlot).order_by(TimeSlot.day_of_week, TimeSlot.start_time).all()
    teachers = Teacher.query.all()
    timeslots = TimeSlot.query.filter_by(is_break=False).order_by(TimeSlot.day_of_week, TimeSlot.start_time).all()
    return render_template('unavailables.html', unavailables=unavailables, teachers=teachers, timeslots=timeslots)

@app.route('/unavailables/add', methods=['POST'])
@login_required
def add_unavailable():
    if current_user.role != 'admin': return redirect(url_for('schedules'))
    teacher_id = request.form.get('teacher_id')
    timeslot_id = request.form.get('timeslot_id')
    reason = request.form.get('reason')
    
    if teacher_id and timeslot_id:
        # Check if already exists
        exists = TeacherUnavailable.query.filter_by(teacher_id=teacher_id, timeslot_id=timeslot_id).first()
        if exists:
            flash('Guru tersebut sudah ditandai izin pada sesi waktu yang dipilih.', 'warning')
        else:
            new_unavail = TeacherUnavailable(teacher_id=teacher_id, timeslot_id=timeslot_id, reason=reason)
            db.session.add(new_unavail)
            # Also delete any existing schedule that might conflict
            Schedule.query.filter_by(teacher_id=teacher_id, timeslot_id=timeslot_id).delete()
            db.session.commit()
            flash('Izin waktu guru berhasil ditambahkan!', 'success')
    return redirect(url_for('unavailables'))

@app.route('/unavailables/delete/<int:id>', methods=['POST'])
@login_required
def delete_unavailable(id):
    if current_user.role != 'admin': return redirect(url_for('schedules'))
    unavail = TeacherUnavailable.query.get_or_404(id)
    db.session.delete(unavail)
    db.session.commit()
    flash('Izin waktu guru berhasil dihapus!', 'success')
    return redirect(url_for('unavailables'))

import random

# --- GREEDY ALGORITHM (Admin Only) ---
@app.route('/generate', methods=['GET', 'POST'])
@login_required
def generate():
    if current_user.role != 'admin': return redirect(url_for('schedules'))
    if request.method == 'POST':
        db.session.query(Schedule).delete()
        
        classrooms = Classroom.query.all()
        subjects = Subject.query.all()
        teachers = Teacher.query.all()
        
        day_map = {'Senin': 1, 'Selasa': 2, 'Rabu': 3, 'Kamis': 4, 'Jumat': 5, 'Sabtu': 6, 'Minggu': 7}
        timeslots = TimeSlot.query.filter_by(is_break=False).all()
        timeslots.sort(key=lambda x: (day_map.get(x.day_of_week, 8), x.start_time))
        
        # Pre-calculate required JPs
        required_jps = []
        for c in classrooms:
            for s in subjects:
                for _ in range(s.weekly_allocations):
                    required_jps.append((c.id, s.id, s.name, c.name))
                    
        # Bottleneck counts
        subj_teacher_count = {}
        for s in subjects:
            subj_teacher_count[s.id] = len([t for t in teachers if t.subject_id == s.id])
            
        unavailables_data = TeacherUnavailable.query.all()
        
        max_retries = 2000
        best_schedules = []
        success = False
        error_msg = ""
        
        for attempt in range(max_retries):
            teacher_schedule = {t.id: set() for t in teachers}
            for unavail in unavailables_data:
                if unavail.teacher_id in teacher_schedule:
                    teacher_schedule[unavail.teacher_id].add(unavail.timeslot_id)
                    
            class_schedule = {c.id: set() for c in classrooms}
            teacher_workload = {t.id: 0 for t in teachers}
            temp_schedules = []
            
            # Acak urutan assignment setiap percobaan
            current_jps = list(required_jps)
            random.shuffle(current_jps)
            # Pastikan mapel bottleneck tetap dieksekusi lebih dulu
            current_jps.sort(key=lambda x: subj_teacher_count[x[1]])
            
            attempt_success = True
            
            for c_id, s_id, s_name, c_name in current_jps:
                eligible = [t for t in teachers if t.subject_id == s_id]
                if not eligible:
                    attempt_success = False
                    error_msg = f"Tidak ada guru untuk mapel {s_name}."
                    break
                    
                placed = False
                
                # SANGAT PENTING: Acak urutan slot waktu agar jadwal tidak menumpuk di hari Senin
                # Ini menyelesaikan masalah "kemacetan" di mana guru habis di awal minggu
                slots = list(timeslots)
                random.shuffle(slots)
                
                # Seimbangkan beban guru
                eligible.sort(key=lambda t: teacher_workload[t.id])
                
                for slot in slots:
                    if slot.id in class_schedule[c_id]: continue
                    
                    for t in eligible:
                        if slot.id not in teacher_schedule[t.id]:
                            class_schedule[c_id].add(slot.id)
                            teacher_schedule[t.id].add(slot.id)
                            teacher_workload[t.id] += 1
                            temp_schedules.append(Schedule(classroom_id=c_id, teacher_id=t.id, subject_id=s_id, timeslot_id=slot.id))
                            placed = True
                            break
                    if placed: break
                    
                if not placed:
                    attempt_success = False
                    error_msg = f"Gagal pada {s_name} kelas {c_name}."
                    break
                    
            if attempt_success:
                success = True
                best_schedules = temp_schedules
                break
                
        if success:
            for sched in best_schedules:
                db.session.add(sched)
            db.session.commit()
            flash('Jadwal berhasil digenerate!', 'success')
        else:
            db.session.rollback()
            db.session.query(Schedule).delete()
            db.session.commit()
            flash(f'Gagal generate jadwal setelah {max_retries} iterasi: {error_msg}', 'danger')
            
        return redirect(url_for('generate'))
        
    return render_template('generate.html')

# --- VIEW SCHEDULE (Public/Tamu & Admin) ---
@app.route('/schedules')
def schedules():
    class_id = request.args.get('class_id')
    teacher_id = request.args.get('teacher_id')
    
    query = Schedule.query
    if class_id:
        query = query.filter(Schedule.classroom_id == class_id)
    if teacher_id:
        query = query.filter(Schedule.teacher_id == teacher_id)
        
    scheds = query.all()
    day_map = {'Senin': 1, 'Selasa': 2, 'Rabu': 3, 'Kamis': 4, 'Jumat': 5, 'Sabtu': 6, 'Minggu': 7}
    timeslots = TimeSlot.query.all()
    timeslots.sort(key=lambda x: (day_map.get(x.day_of_week, 8), x.start_time))
    
    days = sorted(list(set([t.day_of_week for t in timeslots])), key=lambda x: day_map.get(x, 8))
    unique_times = sorted(list(set([(t.start_time, t.end_time) for t in timeslots])))
    
    classrooms = Classroom.query.all()
    teachers = Teacher.query.all()
    
    if current_user.is_authenticated and current_user.role == 'admin':
        return render_template('schedules.html', 
                               schedules=scheds, 
                               classrooms=classrooms, 
                               teachers=teachers, 
                               selected_class=class_id, 
                               selected_teacher=teacher_id,
                               timeslots=timeslots,
                               days=days,
                               unique_times=unique_times)
    else:
        return render_template('public_schedules.html', 
                               schedules=scheds, 
                               classrooms=classrooms, 
                               teachers=teachers, 
                               selected_class=class_id, 
                               selected_teacher=teacher_id,
                               timeslots=timeslots,
                               days=days,
                               unique_times=unique_times)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
