# Tutorial Lengkap Menjalankan Website (Aplikasi Jadwal Mengajar)

Berikut adalah panduan langkah demi langkah untuk menjalankan aplikasi website ini di komputer/laptop Anda. Panduan ini menggunakan **Git Bash** sebagai terminal.

## Langkah 1: Persiapan Ekstrak File
1. Pastikan Anda telah mengunduh file `.zip` (project website).
2. Klik kanan pada file `.zip` tersebut dan pilih **Extract Here** atau **Extract to [nama_folder]**.
3. Buka folder hasil ekstraksi tersebut. Anda akan melihat file-file seperti `app.py`, `models.py`, folder `templates`, dan lainnya.

## Langkah 2: Membuka Git Bash
1. Di dalam folder hasil ekstraksi (tempat di mana file `app.py` berada), **klik kanan** pada area kosong di dalam folder tersebut.
2. Pilih opsi **"Open Git Bash here"** (jika menggunakan Windows 11, pilih "Show more options" terlebih dahulu lalu klik "Open Git Bash here").
3. Jendela terminal Git Bash (layar hitam/hitam transparan) akan terbuka.

## Langkah 3: Mengaktifkan Virtual Environment
Virtual environment digunakan agar library yang dibutuhkan website tidak bentrok dengan library lain di komputer Anda. Karena pada folder ini sudah terdapat folder `venv`, kita tinggal mengaktifkannya.

Ketik perintah berikut di Git Bash lalu tekan **Enter**:
```bash
source venv/Scripts/activate
```
*(Tanda bahwa virtual environment telah aktif adalah munculnya tulisan `(venv)` di sebelah kiri pada baris ketikan Anda).*

> **Catatan:** Jika perintah di atas gagal (misalnya karena `venv` rusak atau berbeda sistem), Anda bisa membuat virtual environment baru dengan mengetikkan:
> `python -m venv venv` 
> lalu jalankan kembali perintah aktivasi di atas.

## Langkah 4: Menginstal Library yang Dibutuhkan
Karena sekarang sudah ada file `requirements.txt` yang menyimpan daftar library secara otomatis, instalasi menjadi lebih mudah. Jalankan perintah ini dan tekan **Enter**:
```bash
pip install -r requirements.txt
```
Tunggu hingga proses instalasi (download) selesai 100%.

## Langkah 5: Menyiapkan Database dan Data Awal
Agar aplikasi bisa langsung digunakan dan Anda bisa login, Anda perlu menjalankan script untuk mengisi data awal (seeding).

Ketik perintah berikut dan tekan **Enter**:
```bash
python seed.py
```
*(Script ini akan memastikan database dan akun admin bawaan dibuat)*.

## Langkah 6: Menjalankan Server Website
Setelah semua siap, jalankan aplikasi website dengan perintah:
```bash
python app.py
```

Jika berhasil, Anda akan melihat tulisan yang memberitahukan bahwa server sedang berjalan, biasanya seperti ini:
`* Running on http://127.0.0.1:5000`

## Langkah 7: Membuka Website di Browser
1. Buka browser kesayangan Anda (Google Chrome, Firefox, Edge, dll).
2. Ketikkan alamat berikut di bagian atas (address bar):
   **http://127.0.0.1:5000** atau **http://localhost:5000**
3. Tekan **Enter**, dan website sudah bisa digunakan!

---

### Cara Login sebagai Admin (Bawaan)
- **Username:** `admin`
- **Password:** `admin`

*(Pastikan untuk mengganti password nanti jika diperlukan)*

---

### Cara Mematikan Server
Jika Anda sudah selesai menggunakan aplikasi dan ingin mematikan server:
1. Kembali ke jendela Git Bash.
2. Tekan kombinasi tombol **Ctrl + C** pada keyboard Anda.
3. Server berhasil dimatikan. Untuk menutup Git Bash, Anda bisa langsung klik tombol silang (X) atau ketik `exit`.
